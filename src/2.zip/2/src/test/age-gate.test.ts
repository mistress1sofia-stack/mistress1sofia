import { describe, expect, it } from 'vitest';
import { AGE_GATE_SCRIPT, AGE_KEY } from '@/components/site/AgeGate';

// Runs the real inline script against a fake page and storage, the way a browser would before first paint.
function run(stored: string | null | 'throws', now: number) {
  const documentElement = { dataset: {} as Record<string, string> };
  const localStorage = {
    getItem: (key: string) => {
      if (stored === 'throws') throw new Error('storage blocked');
      return key === AGE_KEY ? stored : null;
    },
  };
  const realNow = Date.now;
  Date.now = () => now;
  try {
    new Function('document', 'localStorage', AGE_GATE_SCRIPT)({ documentElement }, localStorage);
  } finally {
    Date.now = realNow;
  }
  return documentElement.dataset['age'];
}

const DAY = 24 * 60 * 60 * 1000;
const NOW = 1_800_000_000_000;

describe('Age gate script', () => {
  it('marks a visitor confirmed less than 30 days ago as verified', () => {
    expect(run(JSON.stringify({ t: NOW - 29 * DAY }), NOW)).toBe('yes');
  });
  it('asks again once the confirmation is older than 30 days', () => {
    expect(run(JSON.stringify({ t: NOW - 31 * DAY }), NOW)).toBe('gate');
  });
  it('shows the gate for a first-time visitor', () => {
    expect(run(null, NOW)).toBe('gate');
  });
  it('shows the gate when the stored value is damaged', () => {
    expect(run('not json', NOW)).toBe('gate');
    expect(run(JSON.stringify({ nothing: true }), NOW)).toBe('gate');
  });
  it('shows the gate when browser storage is blocked', () => {
    expect(run('throws', NOW)).toBe('gate');
  });
});
